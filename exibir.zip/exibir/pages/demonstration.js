import TableDemonstration from '../components/TableDemonstration'

import Head from 'next/head'

export default function About() {
  return (
    <>
      <Head>
        <title>Collumn Action</title>
      </Head>

      <h1>Collumn Action Demonstration</h1>

      <TableDemonstration />

    </>
  )
}
