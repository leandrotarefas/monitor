import TableStatusIntegrations from '../components/TableStatusIntegrations'

import Head from 'next/head'

export default function About() {
  return (
    <>
      <Head>
        <title>Integrations</title>
      </Head>

      <h1>Integrations</h1>

    <TableStatusIntegrations/>

    </>
  )
}
