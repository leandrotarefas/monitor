import TableStatusLog from '../components/TableStatusLog'

import Head from 'next/head'

export default function About() {
  return (
    <>
      <Head>
        <title>Logs</title>
      </Head>

      <h1>Logs</h1>

      <TableStatusLog />

    </>
  )
}
