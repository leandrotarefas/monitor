import CenteredMenu from '../components/app/CenteredMenu';

const menuLinks = [
  { label: 'Integrations', href: '/integrations' },
  { label: 'Logs', href: '/logs' },
  { label : 'Demonstration', href: '/demonstration'}
];

export default function Home() {
  return (
    <CenteredMenu links={menuLinks} title="Telas Disponiveis" subtitle="Escolha o tipo de Tela:"/>
  );
}
