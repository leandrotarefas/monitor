import styles from "../styles/TableStatusLog.module.css"
import TableStatusData from "./app/TableStatusData"

const TableStatusLog = () => {

  const headers = ['Identificador', 'Responsável', 'Solicitação', 'Conclusão', 'Tipo', 'Nome', 'Status'];

  const values = [
    [3918, 'Leandro M Melo', '01/01/2023', '01:14:05', 'Funcionarios', "Leandro", { action: { type: "canceled", link: "/" } }],
    [3919, 'Leandro M Melo', '02/05/2023', '01:04:05', 'Funcionarios', "Leandro", { action: { type: "finished", link: "/" } }],
    [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios', "Leandro", { action: { type: "pending", link: "/" } }],
    [3915, 'Leandro M Melo', '04/07/2023', '01:34:05', 'Funcionarios', "Leandro", { action: { type: "canceled", link: "/" } }],
    [3916, 'Leandro M Melo', '05/08/2023', '01:04:05', 'Funcionarios', "Leandro", { action: { type: "pending", link: "/" } }],
  ];

  return (
    <div className={styles.logTable}>
      <TableStatusData headers={headers} values={values}/>
    </div>
  );

};

export default TableStatusLog;