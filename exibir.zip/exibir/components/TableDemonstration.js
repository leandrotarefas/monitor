import styles from "../styles/TableStatusLog.module.css"
import  TableStatusData from "./app/TableStatusData"

const handleSelectChange = (event) => {
  console.log('Valor selecionado:', event.target.value);
  // Outras lógicas conforme necessário
};

const handleSelectModalChange = (value) => {
  console.log('Valor selecionado:', value);
  // Outras lógicas conforme necessário
};

const TableStatusLog = () => {

    

    const headers = ['Identificador','Responsável','Solicitação','Conclusão','Tipo','Nome','Status'];

    const options = [{index:"", value:"", label:"selecione"},{index:0, value:"INSERT", label:"Add"},{index:1, value:"DELETE", label:"Remove"},{index:2, value:"UPDATE", label:"Reload"}]

    const values = [
      [9999, 'Leandro M Melo', '05/08/2023', '01:04:05', 'Funcionarios',"Leandro", {action:{options, onChangeCallback:handleSelectModalChange, modal:true}}],
    ];

    /*

    const options = [{index:"", value:"", label:"selecione"},{index:0, value:"INSERT", label:"Add"},{index:1, value:"DELETE", label:"Remove"},{index:2, value:"UPDATE", label:"Reload"}]

        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", "Waiting"],
        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", {action:{type:"pending"}}],
        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", {action:{type:"finished"}}],
        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", {action:{type:"canceled"}}],

        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", {action:{type:"on"}}],
        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", {action:{type:"off"}}],
        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", {action:{type:"zero"}}],
        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", {action:{type:"cem"}}],





        [3919, 'Leandro M Melo', '02/05/2023', '01:04:05', 'Funcionarios',"Leandro", {action:{type:"finished"}}],
        [3910, 'Leandro M Melo', '03/06/2023', '01:24:05', 'Funcionarios',"Leandro", {action:{type:"pending"}}],
        [3915, 'Leandro M Melo', '04/07/2023', '01:34:05', 'Funcionarios',"Leandro", {action:{type:"canceled"}}],
        [3916, 'Leandro M Melo', '05/08/2023', '01:04:05', 'Funcionarios',"Leandro", {action:{type:"pending", link: "/"}}],
        [9999, 'Leandro M Melo', '05/08/2023', '01:04:05', 'Funcionarios',"Leandro", {action:{options, onChangeCallback:handleSelectChange}}],
        [9999, 'Leandro M Melo', '05/08/2023', '01:04:05', 'Funcionarios',"Leandro", {action:{options, onChangeCallback:handleSelectModalChange, modal:true}}],

    */

    return (
        <div className={styles.logTable}>
          <TableStatusData headers={headers} values={values}/>
        </div>
      );

  };
  
  export default TableStatusLog;