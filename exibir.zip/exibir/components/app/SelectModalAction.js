
import { useState } from 'react';

import styles from "../../styles/SelectModalAction.module.css";

const SelectModalAction = ({ options, onChangeCallback }) => {

  const [showModal, setShowModal] = useState(false);
  const [currentValue, setCurrentValue] = useState(options[0].value);
  const [pendingValue, setPendingValue] = useState(null); // Valor pendente para confirmação

  const handleSelectChange = (event) => {
    const value = event.target.value;
    if (!value) {
      setCurrentValue(value); // Atualiza o valor atual com o valor pendente
      return;
    }
    setPendingValue(event.target.value); // Define o valor pendente
    setShowModal(true); // Mostra o modal de confirmação
  };

  const handleConfirm = () => {
    setCurrentValue(pendingValue); // Atualiza o valor atual com o valor pendente
    onChangeCallback(pendingValue); // Chama a função callback com o valor pendente
    setShowModal(false); // Fecha o modal
    setPendingValue(null); // Limpa o valor pendente
  };

  const handleCancel = () => {
    setShowModal(false); // Fecha o modal sem alterar o valor
    setPendingValue(null); // Limpa o valor pendente
  };

  return (
    <>
      <select value={currentValue} onChange={handleSelectChange}>
        {options.map((option, index) => (
          <option key={index} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>

      {showModal && (
        <div className={styles.modalOverlay}>
          <div className={styles.modal}>
          <p>Tem certeza de que deseja alterar a opção?</p>
          <button className={styles.confirmButton} onClick={handleConfirm}>Confirmar</button>
          <button className={styles.cancelButton} onClick={handleCancel}>Cancelar</button>
          </div>
        </div>
      )}
    </>
  );
};

export default SelectModalAction; 