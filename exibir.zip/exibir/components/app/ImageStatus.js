import Image from 'next/image';

const ImageStatus = ({ type }) => {
    let imagePath;

    switch (type) {
        case 'finished':
            imagePath = '/images/status/_finished.png';
            break;
        case 'pending':
            imagePath = '/images/status/_pending.png';
            break;
        case 'canceled':
            imagePath = '/images/status/_canceled.png';
            break;
            
        //plus
        case 'zero':
            imagePath = '/images/status/_0.png';
            break;

        case 'cem':
            imagePath = '/images/status/_100.png';
            break;

        case 'off':
            imagePath = '/images/status/_desligar.png';
            break;

        case 'on':
            imagePath = '/images/status/_ligar.png';
            break;

        default:
            imagePath = '/images/status/_default.png';
    }

    return <Image src={imagePath} alt={type} width={30} height={30} />;
};

export default ImageStatus;