import Link from 'next/link';
import ImageStatus from './ImageStatus'

const ImageLink = ({ type, link }) => {

    return(
        <Link href={link}>
            <a>
                <ImageStatus type={type}/>
            </a>            
        </Link>
    )
};

export default ImageLink;