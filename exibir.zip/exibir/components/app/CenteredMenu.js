import React from 'react';
import Link from 'next/link';
import styles from '../../styles/CenteredMenu.module.css';

const CenteredMenu = ({ links, title, subtitle }) => {
    return (
        
      <div className={styles.container}>
        <div className={styles.header}>
          {title && <h1 className={styles.title}>{title}</h1>}
          {subtitle && <h2 className={styles.subtitle}>{subtitle}</h2>}
        </div>
        <div className={styles.menu}>
          {links.map((link, index) => (
            <Link key={index} href={link.href}>
              <a className={styles.menuItem}>{link.label}</a>
            </Link>
          ))}
        </div>
      </div>
    );
  };

export default CenteredMenu;
