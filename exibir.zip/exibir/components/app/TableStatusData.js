import styles from '../../styles/TableStatusData.module.css'
import TableActionCollumn from "./TableActionCollumn"

const StatusDataTable = ({ headers, values }) => {

  return (
    <table className={styles.singleTable}>
      <thead>
        <tr>
          {headers.map((header, index) => (
            <th key={index}>{header}</th>
          ))}
        </tr>
      </thead>

      <tbody>
        {values.map((row, rowIndex) => (
          <tr key={rowIndex}>
            {row.map((cell, cellIndex) => (
              cell.action ?
                <td key={cellIndex}>
                  <TableActionCollumn
                    type={cell.action.type}
                    link={cell.action.link}
                    options={cell.action.options}
                    onChangeCallback={cell.action.onChangeCallback}
                    modal={cell.action.modal} />
                </td>
                :
                <td key={cellIndex}>{cell}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default StatusDataTable;