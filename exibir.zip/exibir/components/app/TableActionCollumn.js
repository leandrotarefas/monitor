import SelectAction from './SelectAction'
import SelectModalAction from './SelectModalAction'
import ImageLink from './ImageLink'
import ImageStatus from './ImageStatus'

const TableActionCollumn = ({ type, link, options = [], onChangeCallback, modal }) => {

    if (options.length > 0) {
        if(!modal){
            return (
                <SelectAction onChangeCallback={onChangeCallback} options={options} />
            )
        }

        return (
            <SelectModalAction onChangeCallback={onChangeCallback} options={options} />
        )
        
    }

    if (!link) {
        return (
            <ImageStatus type={type} />
        )
    }

    return (
        <ImageLink type={type} link={link} />
    )

};

export default TableActionCollumn;