import styles from '../styles/Footer.module.css'
import Image from 'next/image'

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <p>
        <Image src='/images/logo.svg' width={150} height={40}/>
      </p>  
      &nbsp;&nbsp;&nbsp; 
      <p>Mais tempo para gestão de pessoas!</p>
    </footer>
  )
}
