import styles from "../styles/TableStatusLog.module.css"
import TableStatusData from "./app/TableStatusData"

const TableStatusLog = () => {

  const headers = ['Responsável', 'Tipo', 'Criação', 'Edição', 'Nome', 'Status'];

  const values = [
    ['Leandro M Melo', 'Afastamentos', '01/01/2023 as 13:55:00', '01/01/2023 as 15:00:00', 'Bubasaur', { action: { type: "canceled" } }],
    ['Leandro M Melo', 'Afastamentos', '02/01/2023 as 14:55:00', '02/01/2023 as 15:00:00', 'Pikachu', { action: { type: "pending" } }],
    ['Leandro M Melo', 'Afastamentos', '03/01/2023 as 15:55:00', '03/01/2023 as 15:00:00', 'Mew', { action: { type: "finished" } }],
    ['Leandro M Melo', 'Afastamentos', '04/01/2023 as 16:55:00', '04/01/2023 as 15:00:00', 'Goku', { action: { type: "finished" } }]
  ];

  return (
    <div className={styles.logTable}>
      <TableStatusData headers={headers} values={values}/>
    </div>
  );

};

export default TableStatusLog;